package am.ak.mybatis.action.general;

import am.ak.mybatis.action.BaseAction;
import am.ak.mybatis.data.manager.IUserManager;
import am.ak.mybatis.data.model.User;
import am.ak.mybatis.util.Validator;
import com.opensymphony.xwork2.ModelDriven;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * Created by karlen on 4/21/15.
 */
public class RegistrationAction extends BaseAction implements ModelDriven<User> {

    @Autowired
    @Qualifier("userManager")
    private IUserManager userManager;

    private Logger logger = Logger.getLogger(RegistrationAction.class);

    private Logger tracker = Logger.getLogger("Tracker");

    private User user = new User();

    @Override
    public String execute() throws Exception {
        try {
            if (userManager.isExists(user.getEmail())) {
                addFieldError("email", "Email is exists");
                return INPUT;
            }
            userManager.add(user);
            tracker.info("User is registration " + user.getEmail());
            return SUCCESS;
        } catch (Exception e) {
            logger.error("Failed to registration user", e);
            return ERROR;
        }
    }

    @Override
    public void validate() {
        if (Validator.isEmpty(user.getName())) {
            addFieldError("name", "Name is required");
        }

        if (Validator.isEmpty(user.getSurname())) {
            addFieldError("surname", "Surname is required");
        }

        if (user.getGender() == null) {
            addFieldError("gender", "Gender is required");
        }

        if (Validator.isEmpty(user.getEmail())) {
            addFieldError("email", "Email is required");
        } else if (false) {
            addFieldError("email", "Email is incorect");
        }

        if (Validator.isEmpty(user.getPassword())) {
            addFieldError("password", "Password is required");
        }
    }

    public User getModel() {
        return user;
    }
}
