package am.ak.mybatis.util;

/**
 * Created by karlen on 5/16/15.
 */
public interface ScopeKeys {

    String USER     = "user";

    String MESSAGE  = "message";
}
